:-use_module('pl-man-game/main').
:-dynamic estado/1.

%Mapa01________________________________________
cambiar(E):- retractall(estado(_)),assert(estado(E)).

m(D):-doAction(move(D)).
s(D,O):-see(normal,D,O).
g(D):-doAction(get(D)).
u(D):-doAction(use(D)).
d(D):-doAction(drop(D)).
%_______________________________________________
r(medio):-s(up-left,'E'),m(none).
r(medio):-s(left,'E'),m(none).
r(medio):-s(down-right,'E'),m(none).
r(medio):-s(down,'l'),g(down),cambiar(pistola).
r(medio):-s(left,'l'),g(left),cambiar(pistola).
r(medio):-s(right,'l'),g(right),cambiar(pistola).
r(medio):-s(up,'l'),g(up),cambiar(pistola).
r(medio):-s(down,' '),s(up,'#'),s(left,'#'),s(right,' '),m(right),cambiar(nada).
r(medio):-s(down,'.'),m(down).
r(medio):-s(left,'.'),m(left).
r(medio):-s(right,'.'),m(right).
r(medio):-s(up,'.'),m(up).
%_______________________________________________
r(pistola):-s(left,'E'),s(right,'.'),m(right).
r(pistola):-s(left,'E'),m(none).
r(pistola):-s(up-left,'E'),m(none).
r(pistola):-s(down-right,'E'),m(none).
r(pistola):-s(down-left,'E'),m(right),cambiar(op4).
r(pistola):-s(right,'E'),m(left).
r(pistola):-s(down,'.'),m(down).
r(pistola):-s(left,'.'),m(left).
r(pistola):-s(right,'.'),m(right).
r(pistola):-s(up,'.'),m(up).
r(pistola):-s(down,'#'),s(up,'#'),s(left,' '),s(right,' '),m(right),cambiar(op).
r(pistola):-s(down,' '),s(up,'#'),s(left,'#'),s(right,' '),m(right).
r(pistola):-s(down,' '),s(up,'#'),s(left,' '),s(right,' '),m(right).
r(pistola):-s(down,' '),s(up,' '),s(left,' '),s(right,' '),m(up).
r(pistola):-s(down,' '),s(up,' '),s(left,' '),s(right,'#'),m(up),cambiar(arriba).
%_______________________________________________
r(op):-s(down,' '),s(up,'#'),s(left,' '),s(right,' '),m(down).
r(op):-s(down,' '),s(up,' '),s(left,'#'),s(right,' '),m(down).
r(op):-s(left,'.'),m(left).
r(op):-s(right,'.'),m(right).
r(op):-s(up,'.'),m(up).
r(op):-s(down,'.'),m(down).
r(op):-s(down,'#'),s(up,' '),s(left,' '),s(right,' '),m(up),cambiar(op2).
%_______________________________________________
r(op2):-s(up,'#'),m(right),cambiar(op3).
r(op2):-s(down,' '),s(up,'#'),s(left,' '),s(right,' '),s(down-right,' '),m(down).
r(op2):-s(down,' '),s(up,' '),s(left,'#'),s(right,' '),m(down).
r(op2):-s(left,'.'),m(left).
r(op2):-s(right,'.'),m(right).
r(op2):-s(up,'.'),m(up).
r(op2):-s(down,'.'),m(down).
r(op2):-s(down,'#'),s(up,' '),s(left,' '),s(right,' '),m(up).
r(op2):-s(down,' '),s(up,' '),s(left,' '),s(right,'#'),m(up).

%_______________________________________________
r(op3):-s(down,' '),s(up-right,'#'),s(up,' '),s(left,' '),s(right,'#'),m(up),cambiar(arriba).
r(op3):-s(up,'#'),m(right).
%_______________________________________________
r(op4):-s(left,' '),s(right,'.'),m(right),cambiar(pistola).
r(op4):-s(down,' '),s(up,'#'),s(left,' '),s(right,' '),m(down).
r(op4):-s(down,'.'),s(up,' '),s(left,'#'),s(right,' '),m(down),cambiar(pistola).

%_______________________________________________
r(nada):-s(left,'E'),m(right).
r(nada):-s(right,'E'),m(none).
r(nada):-s(up-left,'E'),m(none).
r(nada):-s(down-right,'E'),m(none).
r(nada):-s(down,' '),s(up,'#'),s(left,' '),s(right,' '),m(right).
r(nada):-s(left,'.'),m(left).
r(nada):-s(right,'.'),m(right).
r(nada):-s(up,'.'),m(up).
r(nada):-s(up,'.'),m(up).
r(nada):-s(down,'l'),g(down),cambiar(pistola).
r(nada):-s(left,'l'),g(left),cambiar(pistola).
r(nada):-s(right,'l'),g(right),cambiar(pistola).
r(nada):-s(up,'l'),g(up),cambiar(pistola).
%_______________________________________________
r(arriba):-s(left,'a'),d(right),cambiar(llave).
r(arriba):-s(right,'a'),d(left),cambiar(llave).
r(arriba):-s(down,'a'),d(left),cambiar(llave).
r(arriba):-s(up,'a'),d(left),cambiar(llave).
r(arriba):-s(up,'E'),u(up).
r(arriba):-s(left,'E'),u(left).
r(arriba):-s(right,'E'),u(right).
r(arriba):-s(down,'E'),u(down).
r(arriba):-s(up-left,'E'),m(none).
r(arriba):-s(up-right,'E'),m(none).
r(arriba):-s(down-left,'E'),m(none).
r(arriba):-s(down-right,'E'),m(none).
r(arriba):-s(up,'.'),m(up).
r(arriba):-s(down,'.'),m(down).
r(arriba):-s(left,'.'),m(left).
r(arriba):-s(right,'.'),m(right).

%_______________________________________________
r(llave):-s(left,'a'),g(left).
r(llave):-s(right,'a'),g(right).
r(llave):-s(down,'a'),g(down).
r(llave):-s(up,'a'),g(up).
r(llave):-s(up,'.'),m(up).
r(llave):-s(down,'.'),m(down).
r(llave):-s(left,'.'),m(left).
r(llave):-s(right,'.'),m(right).
r(llave):-s(down,' '),s(left,'#'),m(down).
r(llave):-s(down,'#'),s(left,'#'),m(right),cambiar(recorrido).
%_______________________________________________
r(recorrido):-s(down,'#'),s(up,' '),s(left,' '),s(right,' '),m(right).
r(recorrido):-s(down,'#'),s(up,' '),s(left,' '),s(right,'l'),m(right).
r(recorrido):-s(down,'#'),s(up,'l'),s(left,' '),s(right,' '),m(right).
r(recorrido):-s(down,'#'),s(up,' '),s(left,'l'),s(right,' '),m(right).
r(recorrido):-s(down,' '),s(up,' '),s(left,' '),s(right,'#'),m(down).
r(recorrido):-s(down,' '),s(up,' '),s(left,'#'),s(right,'#'),m(down).
r(recorrido):-s(down,' '),s(up,' '),s(left,' '),s(right,'#'),m(down).
r(recorrido):-s(down,'#'),s(up,' '),s(left,' '),s(right,'#'),m(left),cambiar(recorrido2).

%_______________________________________________
r(recorrido2):-s(up-left,'E'),m(none).
r(recorrido2):-s(left,'E'),m(none).
r(recorrido2):-s(down,'#'),s(up,' '),s(left,' '),s(right,' '),m(left).
r(recorrido2):-s(down,'#'),s(up,'E'),s(left,' '),s(right,' '),m(left).
r(recorrido2):-s(down,'#'),s(up,' '),s(left,' '),s(right,'E'),m(left).
r(recorrido2):-s(down,'#'),s(up,' '),s(left,' '),s(right,' '),m(left).
r(recorrido2):-s(down,'#'),s(up,'#'),s(left,' '),s(right,' '),m(left).
r(recorrido2):-s(down,'#'),s(up,'#'),s(left,' '),s(right,'E'),m(left).
r(recorrido2):-s(down,'-'),u(down),cambiar(final).
%_______________________________________________
r(final):-s(down,'.'),s(up,' '),s(left,'#'),s(right,' '),m(down).
r(final):-s(down,'.'),s(up,' '),s(left,'#'),s(right,'#'),m(down).
r(final):-s(right,'.'),m(right).
%__________________________________________________
r(init):-retractall(estado(_)),assert(estado(medio)).
r:- estado(medio),r(medio).
r:- estado(pistola),r(pistola).
r:- estado(nada),r(nada).
r:- estado(op),r(op).
r:- estado(op2),r(op2).
r:- estado(op3),r(op3).
r:- estado(op4),r(op4).
r:- estado(arriba),r(arriba).
r:- estado(llave),r(llave).
r:- estado(recorrido),r(recorrido).
r:- estado(recorrido2),r(recorrido2).
r:- estado(final),r(final).


