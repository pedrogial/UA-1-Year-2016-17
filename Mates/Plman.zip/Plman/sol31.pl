:-use_module('pl-man-game/main').
:-dynamic estado/1.

%Mapa01________________________________________
cambiar(E):- retractall(estado(_)),assert(estado(E)).

m(D):-doAction(move(D)).
s(D,O):-see(normal,D,O).
g(D):-doAction(get(D)).
u(D):-doAction(use(D)).
d(D):-doAction(drop(D)).

%_______________________________________________
r(arriba):-s(down,'#'),s(right,' '),s(left,' '),s(up,'#'),s(down-right,'#'),move(right).
r(arriba):-s(down,'#'),s(right,'-'),s(left,' '),s(up,' '),s(down-right,'#'),g(right),cambiar(llave).
r(arriba):-s(down,' '),s(right,'#'),s(left,' '),s(up,' '),s(down-right,'-'),m(down).
r(arriba):-s(down,' '),s(right,'.'),s(left,' '),s(up,' '),s(up-left,' '),m(right).
r(arriba):-s(down,'E'),s(right,'.'),s(left,' '),s(up,' '),s(up-left,' '),m(none).
r(arriba):-s(down,' '),s(right,'.'),s(left,'#'),s(up,' '),s(up-left,'#'),m(right).
r(arriba):-s(down,'.'),s(right,' '),s(left,'#'),s(up,'#'),s(down-right,'.'),s(up-left,'#'),m(down).
r(arriba):-s(down,'.'),s(right,' '),s(left,'.'),s(up,'#'),s(down-right,'.'),s(up-left,'#'),m(left).
r(arriba):-s(down,'.'),s(right,' '),s(left,'.'),s(up,' '),s(down-right,'.'),s(up-left,'.'),m(left).
r(arriba):-s(down,' '),s(right,' '),s(left,'#'),s(up,' '),m(down).
r(arriba):-s(down,'.'),s(right,' '),s(left,'.'),s(up,' '),s(down-right,'.'),s(up-left,'#'),m(left).
r(arriba):-s(down,'.'),s(right,' '),s(left,'.'),s(up,'#'),m(down).	
r(arriba):-s(right,'.'),s(down,'.'),m(right).
r(arriba):-s(down,'.'),s(right,'#'),s(left,' '),s(up,'#'),m(down).
r(arriba):-s(down,'.'),s(right,'#'),s(left,'.'),s(up,' '),m(down).
r(arriba):-s(down,'#'),s(right,'#'),s(left,'.'),s(up,' '),m(left).
r(arriba):-s(down,'#'),s(right,' '),s(left,'.'),s(up,'.'),m(up).
r(arriba):-s(down,' '),s(right,' '),s(left,'.'),s(up,' '),m(left).
r(arriba):-s(down,'.'),s(right,' '),s(left,'.'),s(up,' '),m(down).
r(arriba):-s(down,'#'),s(right,' '),s(left,'.'),s(up,' '),m(left).
r(arriba):-s(down,'.'),s(right,' '),s(left,'.'),s(up,'.'),m(up).
%__________________________________________________
r(llave):-s(down,' '),s(right,' '),s(left,' '),s(up,'#'),s(down-right,' '),s(down-left,'-'),d(down),cambiar(coger3).
r(llave):-s(down-left,'-'),s(right,' '),s(down,' '),s(left,' '),s(up,'#'),d(down),cambiar(probar).
r(llave):-s(down,'#'),s(right,' '),s(left,' '),s(up,'#'),m(left).
r(llave):-s(down,'#'),s(right,' '),s(left,' '),s(up,' '),m(up).
r(llave):-s(down,' '),s(right,'#'),s(left,' '),s(up,' '),m(up).
r(llave):-s(down,' '),s(right,' '),s(left,' '),s(up,' '),m(up).
r(llave):-s(down,' '),s(right,' '),s(left,' '),s(up,'#'),m(left).
r(llave):-s(down,' '),s(right,' '),s(left,'|'),s(up,'#'),d(down), cambiar(coger).
%__________________________________________________
r(coger):-s(down,'E'),s(right,'#'),s(left,' '),s(up,' '),m(none),cambiar(coger2).
r(coger):-s(down,' '),s(right,' '),s(left,'|'),s(up,'#'),m(right).
r(coger):-s(down,' '),s(right,' '),s(left,'|'),s(up,'#'),m(right).
r(coger):-s(down,'-'),s(right,' '),s(left,'|'),s(up,'#'),m(right).
r(coger):-s(down,' '),s(right,' '),s(left,' '),s(up,'#'),m(right).
r(coger):-s(down,' '),s(right,'#'),s(left,' '),s(up,'#'),m(down).
r(coger):-s(down,' '),s(right,'#'),s(left,' '),s(up,' '),m(down).
r(coger):-s(down,'#'),s(right,'#'),s(left,' '),s(up,' '),m(left).
r(coger):-s(down,'#'),s(right,' '),s(left,' '),s(up,' '),m(left).
r(coger):-s(down,' '),s(right,' '),s(left,' '),s(up,' '),m(down).
r(coger):-s(down,' '),s(right,'#'),s(left,' '),s(up,' '),m(down).
r(coger):-s(down,'#'),s(right,' '),s(left,'E'),s(up,' '),m(up).
r(coger):-s(down,'E'),s(right,' '),s(left,' '),s(up,' '),m(right).
r(coger):-s(right,'#'),s(left,' '),s(up,' '),s(down,'E'),m(none).
%__________________________________________________
r(coger2):-s(down,' '),s(right,'#'),s(left,' '),s(up,' '),s(down-right,'E'),m(none).
r(coger2):-s(down,'E'),s(right,'#'),s(left,' '),s(up,' '),m(none).
r(coger2):-s(down,' '),s(right,'#'),s(left,' '),s(up,' '),m(down).
r(coger2):-s(down,'#'),s(right,' '),s(left,' '),s(up,' '),m(right).
r(coger2):-s(down,'#'),s(right,'-'),s(left,' '),s(up,'#'),g(right),cambiar(llave).

%__________________________________________________
r(coger3):-s(down,'#'),s(right,'-'),s(left,' '),s(up,'#'),g(right),cambiar(llave2).
r(coger3):-s(down,'#'),s(right,' '),s(left,' '),s(up,' '),s(up-right,'#'),m(right).
r(coger3):-s(down,'-'),s(right,' '),s(left,' '),s(up,'#'),m(right).
r(coger3):-s(down,' '),s(right,' '),s(left,'-'),s(up,'#'),m(right).
r(coger3):-s(down,' '),s(right,' '),s(left,'|'),s(up,'#'),m(right).
r(coger3):-s(down,' '),s(right,' '),s(left,'|'),s(up,'#'),m(right).
r(coger3):-s(down,'-'),s(right,' '),s(left,'|'),s(up,'#'),m(right).
r(coger3):-s(down,' '),s(right,' '),s(left,' '),s(up,'#'),m(right).
r(coger3):-s(down,' '),s(right,'#'),s(left,' '),s(up,'#'),m(down).
r(coger3):-s(down,' '),s(right,'#'),s(left,' '),s(up,' '),m(down).
r(coger3):-s(down,'#'),s(right,'#'),s(left,' '),s(up,' '),m(left).
r(coger3):-s(down,'#'),s(right,' '),s(left,' '),s(up,' '),m(left).
r(coger3):-s(down,' '),s(right,' '),s(left,' '),s(up,' '),m(down).
r(coger3):-s(down,'#'),s(right,' '),s(left,' '),s(up,'#'),m(right).
r(coger3):-s(down,' '),s(right,'#'),s(left,' '),s(up,' '),m(down).
%__________________________________________________
r(llave2):-s(down,' '),s(right,' '),s(left,' '),s(up,'#'),s(down-right,' '),s(down-left,'-'),m(left).
r(llave2):-s(down,'-'),s(right,' '),s(left,' '),s(up,'#'),m(left).
r(llave2):-s(down,'-'),s(right,' '),s(left,'|'),s(up,'#'),u(left), cambiar(comprobar).
r(llave2):-s(down,'#'),s(right,' '),s(left,' '),s(up,'#'),m(left).
r(llave2):-s(down,'#'),s(right,' '),s(left,' '),s(up,' '),m(up).
r(llave2):-s(down,' '),s(right,'#'),s(left,' '),s(up,' '),m(up).
r(llave2):-s(down,' '),s(right,' '),s(left,' '),s(up,' '),m(up).
r(llave2):-s(down,' '),s(right,' '),s(left,' '),s(up,'#'),m(left).
r(llave2):-s(down,' '),s(right,' '),s(left,' '),s(up,'#'),m(left).

%__________________________________________________


r(comprobar):-s(down,'-'),s(right,' '),s(left,' '),s(up,'#'),s(down-right,'-'),m(right).
r(comprobar):-s(down,'-'),s(right,' '),s(left,'|'),s(up,'#'),m(right).
r(comprobar):-s(down,' '),s(right,'-'),s(left,' '),s(up,'#'),d(down),cambiar(comprobar2).
r(comprobar):-s(down,'-'),s(right,' '),s(left,' '),s(up,'#'),s(down-right,' '),d(right).
r(comprobar):-s(down,'-'),s(right,'-'),s(left,' '),s(up,'#'),g(down), cambiar(probar).
r(comprobar):-s(down,'#'),s(right,' '),s(left,'|'),s(up,'#'),m(right).
 
%__________________________________________________
r(probar):-s(down,' '),s(right,'-'),s(left,' '),s(up,'#'),m(left).
r(probar):-s(down,'-'),s(right,' '),s(left,' '),s(up,'#'),m(left).
r(probar):-s(down,'#'),s(right,' '),s(left,'|'),s(up,'#'),u(left),cambiar(comprobar5).
r(probar):-s(down,'-'),s(right,' '),s(left,'|'),s(up,'#'),u(left),cambiar(comprobar4).
%__________________________________________________
r(comprobar2):-s(down,'-'),s(right,'-'),s(left,' '),s(up,'#'),m(left).
r(comprobar2):-s(down,'-'),s(right,' '),s(left,'|'),s(up,'#'),g(down).
r(comprobar2):-s(down,' '),s(right,' '),s(left,'|'),s(up,'#'),u(left),cambiar(comprobar3).
%__________________________________________________
r(comprobar3):-s(down,' '),s(right,' '),s(left,' '),s(up,'#'),d(down).
r(comprobar3):-s(down,'-'),s(right,' '),s(left,' '),s(up,'#'),m(right).
%__________________________________________________
r(comprobar5):-s(down,'#'),s(right,' '),s(left,' '),s(up,'#'),m(right).
r(comprobar5):-s(down,'#'),s(right,' '),s(left,'|'),s(up,'#'),m(right).
r(comprobar5):-s(down,'-'),s(right,' '),s(left,' '),s(up,'#'),s(down-right,' '),m(right).
r(comprobar5):-s(down,' '),s(right,'-'),s(left,' '),s(up,'#'),d(down),cambiar(probar2).
%__________________________________________________
r(comprobar4):-s(down,'-'),s(right,' '),s(left,'|'),s(up,'#'),m(right).
r(comprobar4):-s(down,'#'),s(right,' '),s(left,' '),s(up,'#'),m(left).
r(comprobar4):-s(down,'-'),s(right,' '),s(left,' '),s(up,'#'),m(right).
r(comprobar4):-s(down,' '),s(right,'-'),s(left,' '),s(up,'#'),d(down),cambiar(probar4).
r(comprobar4):-s(down,'-'),s(right, '-'),s(left,' '),s(up,'#'),g(right),cambiar(probar).
%__________________________________________________
r(probar2):-s(down,'-'),s(right,'-'),s(left,' '),s(up,'#'),m(left). 
r(probar2):-s(down,'-'),s(right,' '),s(left,' '),s(up,'#'),g(down).
r(probar2):-s(down,' '),s(right,' '),s(left,' '),s(up,'#'),m(left).
r(probar2):-s(down,'#'),s( right,' '),s(left,' '),s(up,'#'),m(left).
r(probar2):-s(down,'#'),s( right,' '),s(left,'|'),s(up,'#'),u(left),cambiar(otro).
r(probar2):-s(down,'#'),s( right,' '),s(left,' '),s(up,'#'),d(right).
r(probar2):-s(down,'#'),s( right,'-'),s(left,' '),s(up,'#'),m(left).
%__________________________________________________
r(otro):-s(down,'#'),s(right,' '),s(left,'|'),s(up,'#'),s(down-right,'#'),u(left),cambiar(go).
r(otro):-s(down,'#'),s(right,' '),s(left,' '),s(up,'#'),s(down-right,'-'),m(left).
r(otro):-s(down,'#'),s(right,' '),s(left,' '),s(up,'#'),m(right).
r(otro):-s(down,' '),s(right,' '),s(left,' '),s(up,'#'),d(down).
r(otro):-s(down,'-'),s(right,' '),s(left,' '),s(up,'#'),m(right).
r(otro):-s(down,'-'),s(right,'-'),s(left,' '),s(up,'#'),g(down).
r(otro):-s(down,' '),s(right,'-'),s(left,' '),s(up,'#'),m(left),cambiar(p).
r(otro):-s(down,'#'),s(right,' '),s(left,'?'),s(up,'#'),m(left),cambiar(go5).
%__________________________________________________
r(p):-s(down,'-'),s(right,' '),s(left,' '),s(up,'#'),m(left).
r(p):-s(down,'#'),s(right,' '),s(left,' '),s(up,'#'),m(left).
r(p):-s(down,'#'),s(right,' '),s(left,'?'),s(up,'#'),m(left),cambiar(go5).
r(p):-s(down,'#'),s(right,' '),s(left,'|'),s(up,'#'),u(left),cambiar(go).
r(p):-s(down,' '),s(right,' '),s(left,' '),s(up,'#'),m(left).
r(p):-s(down,'#'),s(right,' '),s(left,'|'),s(up,'#'),u(left).
%__________________________________________________
r(probar4):-s(down,'-'),s(right,'-'),s(left,' '),s(up,'#'),m(left).
r(probar4):-s(down,'-'),s(right,' '),s(left,' '),s(up,'#'),g(down).
r(probar4):-s(down,' '),s(right,' '),s(left,' '),s(up,'#'),m(left).
r(probar4):-s(down,' '),s(right,' '),s(left,'|'),s(up,'#'),u(left),cambiar(otro2).
r(probar4):-s(down,'-'),s(right,' '),s(left,'|'),s(up,'#'),g(down).
r(probar4):-s(down,'#'),s(right,' '),s(left,'|'),s(up,'#'),u(left),cambiar(comprobar6).
r(probar4):-s(down,' '),s(right,' '),s(left,' '),s(up,'#'),d(down).
%__________________________________________________
r(otro2):-s(down,' '),s(right,' '),s(left,' '),s(up,'#'),d(down).
r(otro2):-s(down,'-'),s(right,' '),s(left,' '),s(up,'#'),m(right).
r(otro2):-s(down,'-'),s(right,'-'),s(left,' '),s(up,'#'),g(right),cambiar(otro3).
%__________________________________________________
r(otro3):-s(down,'-'),s(right,' '),s(left,' '),s(up,'#'),m(left).
r(otro3):-s(down,'#'),s(right,' '),s(left,'|'),s(up,'#'),u(left),cambiar(otro4).
%__________________________________________________
r(otro4):-s(down,'#'),s(right,' '),s(left,'|'),s(up,'#'),m(right).
r(otro4):-s(down,'#'),s(right,' '),s(left,' '),s(up,'#'),m(right).
r(otro4):-s(down,'-'),s(right,' '),s(left,' '),s(up,'#'),s(down-right,' '),d(right).
r(otro4):-s(down,'-'),s(right,' '),s(left,' '),s(up,'#'),s(down-right,'-'),m(right).
r(otro4):-s(down,'-'),s(right,'-'),s(left,' '),s(up,'#'),g(down),cambiar(p3).
r(otro4):-s(down,' '),s(right,'-'),s(left,' '),s(up,'#'),d(down),cambiar(p6).
r(otro4):-s(down,' '),s(right,' '),s(left,' '),s(up,'#'),m(left),cambiar(otro5).
%__________________________________________________
r(p6):-s(down,'-'),s(right,'-'),s(left,' '),s(up,'#'),g(right).
r(p6):-s(down,'-'),s(right,' '),s(left,' '),s(up,'#'),m(left).
r(p6):-s(down,'#'),s(right,' '),s(left,' '),s(up,'#'),m(left).
r(p6):-s(down,'#'),s(right,' '),s(left,'|'),s(up,'#'),u(left).
r(p6):-s(down,'#'),s(right,' '),s(left,'?'),s(up,'#'),m(left),cambiar(go).
%__________________________________________________
r(p3):-s(down,' '),s(right,'-'),s(left,' '),s(up,'#'),m(left).
r(p3):-s(down,'-'),s(right,' '),s(left,' '),s(up,'#'),m(left).
r(p3):-s(down,'#'),s(right,' '),s(left,' '),s(up,'#'),m(left).
r(p3):-s(down,'#'),s(right,' '),s(left,'|'),s(up,'#'),u(left),cambiar(p4).
%__________________________________________________
r(p4):-s(down,'-'),s(right,' '),s(left,' '),s(up,'#'),m(right).
r(p4):-s(down,' '),s(right,'-'),s(left,' '),s(up,'#'),d(down).
r(p4):-s(down,'-'),s(right,'-'),s(left,' '),s(up,'#'),g(right),cambiar(go7).
r(p4):-s(down,'#'),s(right,' '),s(left,' '),s(up,'#'),m(right).
r(p4):-s(down,' '),s(right,'-'),s(left,' '),s(up,'#'),m(left),cambiar(go10).
%__________________________________________________
r(otro5):-s(down,'#'),s(right,' '),s(left,' '),s(up,'#'),m(left).
r(otro5):-s(down,'#'),s(right,' '),s(left,'|'),s(up,'#'),u(left),cambiar(go).
%__________________________________________________
r(comprobar6):-s(down,'#'),s(right,' '),s(left,'|'),s(up,'#'),m(right).
r(comprobar6):-s(down,'#'),s(right,' '),s(left,' '),s(up,'#'),m(right).
r(comprobar6):-s(down,' '),s(right,' '),s(left,' '),s(up,'#'),d(down).
r(comprobar6):-s(down,'-'),s(right,' '),s(left,' '),s(up,'#'),m(right).
r(comprobar6):-s(down,'-'),s(right,'-'),s(left,' '),s(up,'#'),g(right),cambiar(probar5).

%__________________________________________________
r(probar5):-s(down,'-'),s(right,' '),s(left,' '),s(up,'#'),m(left).
r(probar5):-s(down,'#'),s(right,' '),s(left,' '),s(up,'#'),m(left).
r(probar5):-s(down,'#'),s(right,' '),s(left,'|'),s(up,'#'),u(left),cambiar(comprobar7).
%__________________________________________________
r(comprobar7):-s(down,'#'),s(right,' '),s(left,' '),s(up,'#'),s(down-right,' '),m(left).
r(comprobar7):-s(down,'#'),s(right,' '),s(left,'|'),s(up,'#'),s(down-right,'#'),u(left),cambiar(go).
r(comprobar7):-s(down,'#'),s(right,' '),s(left,' '),s(up,'#'),m(right).
r(comprobar7):-s(down,'-'),s(right,' '),s(left,' '),s(up,'#'),d(right).
r(comprobar7):-s(down,'#'),s(right,' '),s(left,' '),s(up,'#'),m(left),cambiar(go8).
r(comprobar7):-s(down,'-'),s(right,'-'),s(left,' '),s(up,'#'),g(down),cambiar(p2).
%__________________________________________________
r(p2):-s(down,' '),s(right,'-'),s(left,' '),s(up,'#'),m(left).
r(p2):-s(down,'#'),s(right,' '),s(left,'|'),s(up,'#'),u(left),cambiar(go6).
r(p2):-s(down,'#'),s(right,' '),s(left,' '),s(up,'#'),m(left),cambiar(go6).
%__________________________________________________
r(go):-s(down,'#'),s(right,' '),s(left,' '),s(up,'#'),m(left).
r(go):-s(down,'#'),s(right,' '),s(left,'?'),s(up,'#'),m(left).
r(go):-s(down,'#'),s(right,' '),s(left,'#'),s(up,'#'),m(none),cambiar(abajo).
%__________________________________________________
r(go5):-s(down,'#'),s(right,' '),s(left,'#'),s(up,'#'),m(none),cambiar(abajo).
%__________________________________________________
r(go6):-s(down,'#'),s(right,' '),s(left,'|'),s(up,'#'),u(left).
r(go6):-s(down,'#'),s(right,' '),s(left,' '),s(up,'#'),m(left).
r(go6):-s(down,'#'),s(right,' '),s(left,'?'),s(up,'#'),m(left).
r(go6):-s(down,'#'),s(right,' '),s(left,'#'),s(up,'#'),m(none),cambiar(abajo).
%__________________________________________________
r(go7):-s(down,'-'),s(right,' '),s(left,' '),s(up,'#'),m(left).
r(go7):-s(down,'#'),s(right,' '),s(left,'|'),s(up,'#'),u(left).
r(go7):-s(down,'#'),s(right,' '),s(left,' '),s(up,'#'),m(left).
r(go7):-s(down,'#'),s(right,' '),s(left,'?'),s(up,'#'),m(left).
r(go7):-s(down,'#'),s(right,' '),s(left,'#'),s(up,'#'),m(none),cambiar(abajo).
%__________________________________________________
r(go8):-s(down,'#'),s(right,' '),s(left,'?'),s(up,'#'),m(left).
r(go8):-s(down,'#'),s(right,' '),s(left,'#'),s(up,'#'),m(none),cambiar(abajo).
%__________________________________________________
r(go10):-s(down,'-'),s(right,' '),s(left,' '),s(up,'#'),m(left).
r(go10):-s(down,'#'),s(right,' '),s(left,' '),s(up,'#'),m(left).
r(go10):-s(down,'#'),s(right,' '),s(left,'?'),s(up,'#'),m(left).
r(go10):-s(down,'#'),s(right,' '),s(left,'#'),s(up,'#'),m(none),cambiar(abajo).

%__________________________________________________
%__________________________________________________
r(abajo):-s(down,'.'),s(right,'v'),s(left,'#'),s(up,'#'),m(down).
r(abajo):-s(left,'.'),s(up-left,'|'),m(none).
r(abajo):-s(up-right,'|'),m(none).
r(abajo):-s(right,'|'),m(none).
r(abajo):-s(left,'|'),m(none).
r(abajo):-s(down,'.'),m(down).
r(abajo):-s(right,'.'),m(right).
r(abajo):-s(left,'.'),m(left).
r(abajo):-s(up,'.'),m(up).
r(abajo):-s(up,'|'),m(right).
r(abajo):-s(down,' '),s(right,'#'),s(left,' '),s(up,' '),s(up-left,'|'),m(none).
r(abajo):-s(down,' '),s(right,'#'),s(left,'|'),s(up,' '),m(none).
r(abajo):-s(down,' '),s(right,'#'),s(left,' '),s(up,' '),m(left),cambiar(abajo2).
%__________________________________________________
r(abajo2):-s(up-left,'|'),m(none).
r(abajo2):-s(right,'|'),m(none).
r(abajo2):-s(left,'|'),m(none).
r(abajo2):-s(down,'.'),m(down).
r(abajo2):-s(right,'.'),m(right).
r(abajo2):-s(left,'.'),m(left).
r(abajo2):-s(up,'.'),m(up).
r(abajo2):-s(up,'|'),m(right).
r(abajo2):-s(left,' '),m(left).

%__________________________________________________
r(init):-retractall(estado(_)),assert(estado(arriba)).
r:- estado(arriba),r(arriba).
r:- estado(llave),r(llave).
r:- estado(llave2),r(llave2).
r:- estado(coger),r(coger).
r:- estado(coger2),r(coger2).
r:- estado(coger3),r(coger3).
r:- estado(probar),r(probar). 
r:- estado(probar2),r(probar2).
r:- estado(probar4),r(probar4).
r:- estado(probar5),r(probar5).
r:- estado(comprobar),r(comprobar).
r:- estado(comprobar2),r(comprobar2).
r:- estado(comprobar3),r(comprobar3).
r:- estado(comprobar4),r(comprobar4).
r:- estado(comprobar5),r(comprobar5).
r:- estado(comprobar6),r(comprobar6).
r:- estado(comprobar7),r(comprobar7).
r:- estado(otro),r(otro).
r:- estado(otro2),r(otro2).
r:- estado(otro3),r(otro3).
r:- estado(otro4),r(otro4).
r:- estado(otro5),r(otro5).
r:- estado(p),r(p).
r:- estado(p2),r(p2).
r:- estado(p3),r(p3).
r:- estado(p4),r(p4).
r:- estado(p6),r(p6).
r:- estado(go),r(go).
r:- estado(go5),r(go5).
r:- estado(go6),r(go6).
r:- estado(go7),r(go7).
r:- estado(go8),r(go8).
r:- estado(go10),r(go10).
r:- estado(abajo),r(abajo).
r:- estado(abajo2),r(abajo2).


