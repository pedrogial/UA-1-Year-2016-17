%%%%%%
% Nombre: Pedro Gim�nez Aldeguer
% DNI: 15419933C
% Fecha: 24/05/2017
% Grupo: 2
% Pr�ctica: 3
%%%%%%
syms x;
f = cos(x);
v1 = int(f, -pi, pi); 
%v1 = 0
syms k;
v2 = k*int(f, -pi, 0) + k*int(f, 0, pi); 
% v2 = 0

%%%%%%Explicaci�n%%%%%%%%
% los resultados son id�nticos porque el �rea de una funci�n cuando �sta
% toma valores negativos se vuelve negativa. 
% Al calcular estos valores en puntos 'ant�podos' que encierran la misma cantidad de �rea entre s� y el eje x 
% Se general dos valores igual y opuestos que al sumarlos dan cero.
% Logicamente, si multiplicamos el escalar 'k' por el valor del �rea (0),
% obtendremos tambi�n un valor nulo.