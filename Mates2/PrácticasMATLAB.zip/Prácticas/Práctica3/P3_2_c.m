%%%%%%
% Nombre: Pedro Gim�nez Aldeguer
% DNI: 15419933C
% Fecha: 24/05/2017
% Grupo: 2
% Pr�ctica: 3
%%%%%%
syms x;
f = @(x)-x^2+8*x+5;
for k = 2 : 25
n = k*2
xi = linspace(-2, 3, n + 1);
h = (5)/n;
for i = 1 : n + 1
yi(i) = f (xi(i));
end
Ln = h*sum(double(yi(1 : n)))
Rn = h*sum(double(yi(2 : n + 1)))
double([Ln Rn]);pause
end