%%%%%%
% Nombre: Pedro Gim�nez Aldeguer
% DNI: 15419933C
% Fecha: 24/05/2017
% Grupo: 2
% Pr�ctica: 3
%%%%%%
f = sqrt(x+1);
%  Area del anillo:
area = int(f, 0, 3) - int(f, -1, 0)

% �ste resultado lo multiplicamos por el �rea de c�rculo 
% Para conseguir el volumen
% V = pi * 'area a revolucionar' ^ 2 %
Vanillo = pi * area^2;
%Vol.anillo = 50.2655