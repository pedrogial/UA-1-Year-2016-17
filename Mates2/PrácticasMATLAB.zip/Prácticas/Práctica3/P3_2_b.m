%%%%%%
% Nombre: Pedro Gim�nez Aldeguer
% DNI: 15419933C
% Fecha: 24/05/2017
% Grupo: 2
% Pr�ctica: 3
%%%%%%
syms x;
f = @(x)sin(2*x);

for k = 1 : 8
n = k*10
xi = linspace(-1, 5, n + 1);
h = (6)/n;
for i = 1 : n + 1
yi(i) = f (xi(i));
end
Ln = h*sum(double(yi(1 : n)))
Rn = h*sum(double(yi(2 : n + 1)))
double([Ln Rn]);pause
end