%%%%%%
% Nombre: Pedro Gim�nez Aldeguer
% DNI: 15419933C
% Fecha: 24/05/2017
% Grupo: 2
% Pr�ctica: 3
%%%%%%
syms x;
k = 5;
f = sin(x);
v1 = int((k*f), -pi/2, pi/2)
%v1 = 0
v2 = k * int(f, -pi/2, pi/2)
%v2 = 0 

%una integral definida multiplicada por un escalar 'lambda' es equivalente a la integral definida
%de una funcion  'f' * 'lambda'
