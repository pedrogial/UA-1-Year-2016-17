%%%%%%
% Nombre: Pedro Gim�nez Aldeguer
% DNI: 15419933C
% Fecha: 24/05/2017
% Grupo: 2
% Pr�ctica: 3
%%%%%%
syms x;
f=@(x)x^5*log(x);
int(f, x)
%ans = (x^6*(log(x)-1/6)/6