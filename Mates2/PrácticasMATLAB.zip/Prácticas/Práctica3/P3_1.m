%%%%%%
% Nombre: Pedro Gim�nez Aldeguer
% DNI: 15419933C
% Fecha: 24/05/2017
% Grupo: 2
% Pr�ctica: 3
%%%%%%
syms x;
f = @(x)sqrt(x);
for k = 2 : 2 
n = 2^k;
xi = linspace(1 ,2 , n+1);
h = (2 - 1)/n;
for i = 1 : n + 1
yi(i) = f (xi(i));
end
Ln = h*sum(double(yi(1 : n)))
Rn = h*sum(double(yi(2 : n + 1)))
double([Ln Rn]);pause
end
v1 = int(f(x), 1, 2);
v2 = (Ln + Rn)/2;
pcnErr = abs(v2-v1)/v1*100;
%pcnErr = 
%
%   0.0624