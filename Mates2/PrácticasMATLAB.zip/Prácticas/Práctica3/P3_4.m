%%%%%%
% Nombre: Pedro Gim�nez Aldeguer
% DNI: 15419933C
% Fecha: 24/05/2017
% Grupo: 2
% Pr�ctica: 3
%%%%%%
syms x;
f = @(x)x;
g = @(x)(x+1)^2
v1 = int(x + (x+1)^2, 0, 2)
%v1 = 32/3
v2 = int(x, 0, 2) + int((x+1)^2, 0, 2)
%v2 = 32/3 

% Una integral definida de la suma de dos fuciones es equivalente a la misma integral definida de
% ambas funciones por separado sumadas