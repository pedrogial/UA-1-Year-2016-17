%%%%%%
% Nombre: Pedro Gim�nez Aldeguer
% DNI: 15419933C
% Fecha: 24/05/2017
% Grupo: 2
% Pr�ctica: 6
%%%%%%

%DifDiv(x,y) Por Newton

function [resultado] =  newton(px, py)

n = length(px);
tabla = zeros(n, n + 1);
tabla(:,1) = px';
tabla(:,2) = py';

for c = 3 : n+1
    for f = 1 : n - c + 2
          tabla(f,c) = (tabla(f+1,c-1) - tabla(f,c-1))/(tabla(f + (c-2),1) - tabla(f,1)) 
    end
end

resultado = tabla(1 , :)
end
