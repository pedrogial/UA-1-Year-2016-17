%%%%%%
% Nombre: Pedro Gim�nez Aldeguer
% DNI: 15419933C
% Fecha: 24/05/2017
% Grupo: 2
% Pr�ctica: 6
%%%%%%

%En general las 3 funciones de la Pr�ctica 6 no s� si estan bien empleadas
%En px y py se ponen los puntos x y los puntos y

function [P] = lagrange(px,py,x)
n = length(px);
L = ones(1, n);
P = 0;

for i = 1 : n
    for j = 1 : n
        if i ~= j
            L(1,i) = L(1,i) * ((x - px(j))/(px(i)-px(j)));
        end    
    end
    syms l
    P = P + (py(i) * l(1,i));

end