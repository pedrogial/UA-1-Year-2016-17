%%%%%%
% Nombre: Pedro Gim�nez Aldeguer
% DNI: 15419933C
% Fecha: 24/05/2017
% Grupo: 2
% Pr�ctica: 6
%%%%%%

%Devolver� el polinomio resultado de la interpolaci�n

function p = lagrange2( pointx, pointy)

	if (size(pointx) ~= size(pointy))
		p = NaN;
	
    else
		syms l p a y;
		i = 1;
		k = 1;
		p = 0;
		temp = size(pointx);
		tamano = temp(2);
    
		while (i <= tamano)   
			 l = 1;
        
			while(k <= tamano)
				if (k ~= i)
                
					l = l * (a - pointx(k)) / (pointx(i) - pointx(k));
				end
            
				k = k + 1;
            end
			p = p + pointy(i) * l;
			i = i + 1;
			k = 1;
        end
    end
end
