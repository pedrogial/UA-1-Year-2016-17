%%%%%%
% Nombre: Pedro Gim�nez Aldeguer
% DNI: 15419933C
% Fecha: 24/05/2017
% Grupo: 2
% Pr�ctica: 2
%%%%%%
syms x;
f = x^3/((x-1)^2) - 8;
solve(f)
ezplot(f);
hold on;
plot(2, subs(f,2), 'rx')
hold on;
plot(5^(1/2) + 3, subs(f,5^(1/2) + 3), 'rx')
hold on;
plot(3 - 5^(1/2), subs(f,3 - 5^(1/2)), 'rx')