%%%%%%
% Nombre: Pedro Gim�nez Aldeguer
% DNI: 15419933C
% Fecha: 24/05/2017
% Grupo: 2
% Pr�ctica: 2
%%%%%%
syms x y z r

y = (2*x)/(x^2+1)
limit(y, inf)
ezplot(y, [-5, 5])
axis equal

hold on
r = 0*x
z = r

ezplot(z, 'color','g-')
