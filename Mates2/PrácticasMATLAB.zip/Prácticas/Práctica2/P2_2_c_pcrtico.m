%%%%%%
% Nombre: Pedro Gim�nez Aldeguer
% DNI: 15419933C
% Fecha: 24/05/2017
% Grupo: 2
% Pr�ctica: 2
%%%%%%
syms x
f=(x+1)/(sqrt(x-1)-5)
solve(sqrt(x-1)-5);
%Hay un punto cr�tico en x=26, pues e anula el numerador.

ezplot(f, [-1, 28]) 
%la funcion f tiede a -inf en x=26
hold on;
plot(26, 0, 'color', 'rx')