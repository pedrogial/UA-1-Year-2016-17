%%%%%%
% Nombre: Pedro Gim�nez Aldeguer
% DNI: 15419933C
% Fecha: 24/05/2017
% Grupo: 2
% Pr�ctica: 2
%%%%%%
syms dist x ddist
dist = sqrt((x)^2+(x^2-1)^2)
ddist = diff(dist)
solve(ddist)

subs(dist, -(2^(1/2))/2) 
% ... = 1
subs(dist, 0)          
% ... = 0.8660 <- coordenadas x de los 
subs(dist, 2^(1/2)/2)  
% ... = 0.8660 <-  puntos mas cercanos
y = x^2 + 1
subs(y, -(2^(1/2))/2) %en ambos puntos y = 1.5
subs(y, (2^(1/2))/2)  %La simetr�a es Par

