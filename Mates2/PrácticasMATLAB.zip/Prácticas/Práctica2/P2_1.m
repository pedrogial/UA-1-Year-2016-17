%%%%%%
% Nombre: Pedro Gim�nez Aldeguer
% DNI: 15419933C
% Fecha: 24/05/2017
% Grupo: 2
% Pr�ctica: 2
%%%%%%
syms x h
 
limit((log(x+h)-log(x))/h, h, 0)
%%%%%%
