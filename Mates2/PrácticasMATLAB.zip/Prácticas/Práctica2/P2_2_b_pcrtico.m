%%%%%%
% Nombre: Pedro Gim�nez Aldeguer
% DNI: 15419933C
% Fecha: 24/05/2017
% Grupo: 2
% Pr�ctica: 2
%%%%%%
syms x
f = log(x)/x
%puesto que el numerados se anula en x => 0; buscamos el l�mite por la
%derecha(por la izquierda 'f' no existe) y averiguamos su valor
subs(f, 0.00000001)
%ans tiene a -inf, pues su derivada es negativa y f es c�ncava hacia abajo
