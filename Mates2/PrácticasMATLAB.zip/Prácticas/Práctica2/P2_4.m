%%%%%%
% Nombre: Pedro Gim�nez Aldeguer
% DNI: 15419933C
% Fecha: 24/05/2017
% Grupo: 2
% Pr�ctica: 2
%%%%%%
syms x y long area
y = 6 - (pi*x)/2 - x
area = y*2*x+0.5*pi*x^2
darea=diff(area)
solve(darea)
ladoinferior = 2*ans 
%es la longitud de * 2 (~3.3606)
lateralrecto = 6 - (pi*(12/(pi + 4)))/2 - (12/(pi + 4)) 
%es la longitud de y (~1,6803)
