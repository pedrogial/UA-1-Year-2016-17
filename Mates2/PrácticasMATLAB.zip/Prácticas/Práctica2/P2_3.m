%%%%%%
% Nombre: Pedro Gim�nez Aldeguer
% DNI: 15419933C
% Fecha: 24/05/2017
% Grupo: 2
% Pr�ctica: 2
%%%%%%
syms x vol area
a = 3*x
b = x
y = 50/(x^2)
c = y
area=2*a*b+2*b*c+2*c*a
precio = 60*x^2 + 48*y*x
ezplot(diff(precio))
solve(diff(precio))
solx = 20^(1/3)
%%%%%%%
a = 8.1433
b = 2.7144
c = 6.7861