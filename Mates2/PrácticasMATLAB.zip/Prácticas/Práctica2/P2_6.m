%%%%%%
% Nombre: Pedro Gim�nez Aldeguer
% DNI: 15419933C
% Fecha: 24/05/2017
% Grupo: 2
% Pr�ctica: 2
%%%%%%
xi=1:10
yi(1)=3.5;yi(2)=4;yi(3)=8;yi(4)=9.5; yi(5)=10; yi(6)=12; yi(7)=14; yi(8)=16; yi(9)=18.5; yi(10)=20

plot(x, y, 'rx')
syms m
f(m)=sum((yi - m*xi)^2)
fdiff=diff(f, m)
fm = double(solve(fdiff==0))