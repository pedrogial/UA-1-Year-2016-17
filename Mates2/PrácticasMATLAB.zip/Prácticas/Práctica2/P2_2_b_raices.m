%%%%%%
% Nombre: Pedro Gim�nez Aldeguer
% DNI: 15419933C
% Fecha: 24/05/2017
% Grupo: 2
% Pr�ctica: 2
%%%%%%
syms x;
f = log(x)/x;
solve(f);
plot(1, 0, 'rx');