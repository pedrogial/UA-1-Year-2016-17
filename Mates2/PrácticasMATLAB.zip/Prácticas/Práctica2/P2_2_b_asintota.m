%%%%%%
% Nombre: Pedro Gim�nez Aldeguer
% DNI: 15419933C
% Fecha: 24/05/2017
% Grupo: 2
% Pr�ctica: 2
%%%%%%
syms x;
f = log(x)/x;
limit(f, inf);
%ans = 0, as�ntota horizontal en 0 %%% x = +inf
limit(f, 0.0001);

%ans= -100000*log(100000), seg�n la derivada df/dx hay una as�ntota vertical con lim -inf en x = 0+
ezplot(f);
hold on;
fplot(0, [-100,100], 'r')

