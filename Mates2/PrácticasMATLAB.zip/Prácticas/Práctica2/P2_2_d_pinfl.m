%%%%%%
% Nombre: Pedro Gim�nez Aldeguer
% DNI: 15419933C
% Fecha: 24/05/2017
% Grupo: 2
% Pr�ctica: 2
%%%%%%
syms x
f = x^3/(x - 1)^2 - 8;
d2f = diff(diff(f));
solve(d2f);
ezplot(f);
hold on;
plot(0, subs(f, 0), 'rx'); 
%punto de inflexi�n de f