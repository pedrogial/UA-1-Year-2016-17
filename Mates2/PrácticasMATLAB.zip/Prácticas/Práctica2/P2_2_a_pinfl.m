%%%%%%
% Nombre: Pedro Gim�nez Aldeguer
% DNI: 15419933C
% Fecha: 24/05/2017
% Grupo: 2
% Pr�ctica: 2
%%%%%%

syms x y z
y = 2*x/(x^2+1)
 
t=diff(diff(y))
 
solve(t)

 
syms a b c
a = 2*3^(1/2)/((3^(1/2))^2+1)

b = 2*-(3^(1/2))/((-3^(1/2))^2+1)

c = 2*0/(0^2+1)

ezplot(y, 'b')
hold on

plot(3^(1/2), a, 'rx')
hold on

plot(-3^(1/2), b, 'rx')
hold on

plot(0, c, 'rx')
%%Me da error%%