%%%%%%
% Nombre: Pedro Gim�nez Aldeguer
% DNI: 15419933C
% Fecha: 24/05/2017
% Grupo: 2
% Pr�ctica: 2
%%%%%%
syms x;
f = log (x) / x;
df=diff(f);
solve(df);
% ans = exp(1) que es 'e^1'
format short
subs(f, exp(1))
% ans = 0.3679 por lo que hay un punto de inflexi�n en P(e, 0.3679)

ezplot(f);
hold on;
plot(exp(1), 0.3679, 'rx')