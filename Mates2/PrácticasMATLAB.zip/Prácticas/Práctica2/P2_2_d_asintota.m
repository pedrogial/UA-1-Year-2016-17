%%%%%%
% Nombre: Pedro Gim�nez Aldeguer
% DNI: 15419933C
% Fecha: 24/05/2017
% Grupo: 2
% Pr�ctica: 2
%%%%%%
syms x;
f = x^3/(x - 1)^2 - 8;
limit(f, -inf); 
%no existe as�ntota en -inf
limit(f, inf); 
%no existe as�ntota en inf. 

%Por el punto cr�ticos se deduce que hay una as�ntota vertical x=1, 
%Punto en el cual f tiende a infinito tanto por la izquierda como por la derecha.
ezplot(f);
hold on
plot(1, 0, 'rx');
