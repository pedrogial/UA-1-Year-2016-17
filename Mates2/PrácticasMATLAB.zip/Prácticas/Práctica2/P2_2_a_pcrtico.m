%%%%%%
% Nombre: Pedro Gim�nez Aldeguer
% DNI: 15419933C
% Fecha: 24/05/2017
% Grupo: 2
% Pr�ctica: 2
%%%%%%
syms x y z
y =(2*x)/(x^2 + 1)
z=diff(y)
ezplot(y, [-3, 3])
solve(z)

plot(-1, -1, 'g+')
hold on
plot(1, 1, 'g+')