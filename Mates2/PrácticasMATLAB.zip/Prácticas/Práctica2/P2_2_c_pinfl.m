%%%%%%
% Nombre: Pedro Gim�nez Aldeguer
% DNI: 15419933C
% Fecha: 24/05/2017
% Grupo: 2
% Pr�ctica: 2
%%%%%%
syms x;
f=(x+1)/(sqrt(x-1)-5);
d2f= diff(diff(f));
solve(d2f);
ezplot(f);
hold on;
plot(119 - 48*6^(1/2), subs(f, 119 - 48*6^(1/2)), 'rx');
hold on;
plot(48*6^(1/2) + 119, subs(f, 48*6^(1/2) + 119), 'rx');
%�stos son los puntos de inflexion de 'f'