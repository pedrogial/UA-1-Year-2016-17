%%%%%%
% Nombre: Pedro Gim�nez Aldeguer
% DNI: 15419933C
% Fecha: 24/05/2017
% Grupo: 2
% Pr�ctica: 2
%%%%%%
syms x;
f = (x + 1)/((x - 1)^(1/2) - 5);
limit(f, inf) 
%no existe asintota en el infinito y no existe la funci�n en el -inf
%la �nica as�ntota de la funci�n es vertical y se encuentra en x=26