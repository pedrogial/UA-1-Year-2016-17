%%%%%%
% Nombre: Pedro Gim�nez Aldeguer
% DNI: 15419933C
% Fecha: 24/05/2017
% Grupo: 2
% Pr�ctica: 2
%%%%%%
syms x;
f=(x+1)/(sqrt(x-1)-5);
solve(f);
%ans = -1
ezplot(f);
hold on;
plot(-1, 0, 'rx');