%%%%%%
% Nombre: Pedro Gim�nez Aldeguer
% DNI: 15419933C
% Fecha: 24/05/2017
% Grupo: 2
% Pr�ctica: 5
%%%%%%

%syms x
%f = x^2-sin(x)-0.5;
%Secante(f,0,2,10^-3,10^-3,4)

function [fila,ractual,iteracionactual] = Secante(f,a,b,tolerancia,epsilon,maxiter)
    i=1;
    aux = 0;
    conv = false;
    fila{1}.a = a;
    fila{1}.b = b;
    
    while(conv == false)
        fila{i}.fa = double(subs(f,fila{i}.a));
        fila{i}.fb = double(subs(f,fila{i}.b));
        
        if (abs(fila{i}.fa)>abs(fila{i}.fb))
            aux = fila{i}.a;
            fila{i}.a=fila{i}.b;
            fila{i}.b=aux;
        end;
        
        fila{i}.h = fila{i}.fa*(fila{i}.b-fila{i}.a)/(fila{i}.fb-fila{i}.fa);
        fila{i}.r =(fila{i}.a-fila{i}.h);
        fila{i}.fr = double(subs(f,fila{i}.r));
        
        fila{i+1}.b = fila{i}.r;
        fila{i+1}.a = fila{i}.a;
        
        if(abs(fila{i}.h)<tolerancia || abs(fila{i}.fr)<epsilon || i==maxiter) 
            conv = true;
        end
        iteracionactual = i;
        ractual = fila{i}.r;
        i = i+1;
    end
    
end  