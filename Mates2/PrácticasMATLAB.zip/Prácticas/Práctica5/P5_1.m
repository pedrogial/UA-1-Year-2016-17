%%%%%%
% Nombre: Pedro Gim�nez Aldeguer
% DNI: 15419933C
% Fecha: 24/05/2017
% Grupo: 2
% Pr�ctica: 5
%%%%%%

%syms x
% f = x^2-sin(x)-0.5;
%Bisection(f,0,2,10^-3,10^-3,4)
%Bisection(f,-1,0,10^-3,10^-3,4)

function [fila,ractual,iteracionactual] = Bisection(f,a,b,tolerancia,epsilon,maxiter)

    
    i=1;
    conv = false;
    fila{1}.a = a;
    fila{1}.b = b;
    while(conv == false)
        fila{i}.r =(fila{i}.a+fila{i}.b)/2;
        fila{i}.h =abs((fila{i}.b-fila{i}.a)/2);
        fila{i}.fa = double(subs(f,fila{i}.a));
        fila{i}.fr = double(subs(f,fila{i}.r));
 
        if(fila{i}.fa*fila{i}.fr<0)
            fila{i+1}.b=fila{i}.r;
            fila{i+1}.a=fila{i}.a;
        else
            fila{i+1}.b=fila{i}.b;
            fila{i+1}.a=fila{i}.r;
        end;
        if(fila{i}.h<tolerancia || abs(fila{i}.fr)<epsilon || i==maxiter) 
            conv = true;
        end
        iteracionactual = i;
        ractual = fila{i}.r;
        i = i+1;
    end
    
end
