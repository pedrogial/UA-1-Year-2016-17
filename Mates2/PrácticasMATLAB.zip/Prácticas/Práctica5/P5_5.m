%%%%%%
% Nombre: Pedro Gim�nez Aldeguer
% DNI: 15419933C
% Fecha: 24/05/2017
% Grupo: 2
% Pr�ctica: 5
%%%%%%
%Utilizar en el ejercicio 1
syms x, i;
f = exp^x - 4x^2;
a = -1;
b = 0;
maxiter = 4;
error=1000;
i = 0;
%Utilizar en el ejercicio 3
a = 0;
b = 1;
i = 0;
error = 100;
c2 = 1;
%Utilizar en el ejercicio 4
a = 4;
b = 4.5;
c3 = 4.25;
tolerancia = 0.001;
error = 1;
i = 0;
%%%Me dan Error