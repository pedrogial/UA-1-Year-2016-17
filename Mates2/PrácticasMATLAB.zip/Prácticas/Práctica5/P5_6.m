%%%%%%
% Nombre: Pedro Gim�nez Aldeguer
% DNI: 15419933C
% Fecha: 24/05/2017
% Grupo: 2
% Pr�ctica: 5
%%%%%%
%M�todo de Steffensen
%Lo he hecho con un while aunque da error de "Too many output arguments"
while (error >= tolerancia && i  <= 4)
    i = i + 1; 
    X1 = Xn - ((subs(y, Xn))^2/(subs(y, (Xn + subs(Xn))) - subs(y, Xn)));
    error = abs((X1 - Xn)/X1);
    Xn = X1;
end