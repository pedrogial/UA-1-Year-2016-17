%%%%%%
% Nombre: Pedro Gim�nez Aldeguer
% DNI: 15419933C
% Fecha: 24/05/2017
% Grupo: 2
% Pr�ctica: 5
%%%%%%

%syms x
% f = x^2-sin(x)-0.5;
%Newton(f,2,10^-3,10^-3,4)
%Newton(f,-1,10^-3,10^-3,4)

function [fila,ractual,iteracionactual] = Newton(f,a,tolerancia,epsilon,maxiter)
    i=1;
    aux = 0;
    conv = false;
    fila{1}.a = a;
    while(conv == false)
        
        fila{i}.fa = double(subs(f,fila{i}.a));
        fila{i}.dfa = double(subs(diff(f),fila{i}.a));
        fila{i}.h = fila{i}.fa/fila{i}.dfa;

        fila{i}.r =(fila{i}.a-fila{i}.h);
        fila{i}.fr = double(subs(f,fila{i}.r));
        
        if(abs(fila{i}.h)<tolerancia || abs(fila{i}.fr)<epsilon || i==maxiter) 
            conv = true;
        else
            iteracionactual = i;
            ractual = fila{i}.r;
            fila{i+1}.a = fila{i}.r;
            i = i+1;
        end
    end
    
end