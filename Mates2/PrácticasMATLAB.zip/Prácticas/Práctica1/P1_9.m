%%%%%%
% Nombre: Pedro Gim�nez Aldeguer
% DNI: 15419933C
% Fecha: 08/02/2017
% Grupo: 2
% Pr�ctica: 1
%%%%%%
syms x
expand((x^3 + 1)^2)
simplify((x^3 + x^2 - x - 1)/(x - 1))
factor(x^3 + x^2 - x - 1)
pretty((x^3 + 1)^2)
%%%%%%
