%%%%%%
% Nombre: Pedro Gim�nez Aldeguer
% DNI: 15419933C
% Fecha: 08/02/2017
% Grupo: 2
% Pr�ctica: 1
%%%%%%
x = 10/7
y = sym('10/7')
z= double(y)
w= y + 5
t= double(y) + 5
%%%%%%