%%%%%%
% Nombre: Pedro Gim�nez Aldeguer
% DNI: 15419933C
% Fecha: 08/02/2017
% Grupo: 2
% Pr�ctica: 1
%%%%%%
syms x


fplot('x^2+1',[-2,2])
figure
fplot('x^3',[-2,2])


