%%%%%%
% Nombre: Pedro Gim�nez Aldeguer
% DNI: 15419933C
% Fecha: 08/02/2017
% Grupo: 2
% Pr�ctica: 1
%%%%%%

x = 12
y = 5
hip= sqrt(x^2 + y^2)