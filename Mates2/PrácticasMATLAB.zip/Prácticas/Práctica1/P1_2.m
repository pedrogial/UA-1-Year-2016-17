%%%%%%
% Nombre: Pedro Gim�nez Aldeguer
% DNI: 15419933C
% Fecha: 08/02/2017
% Grupo: 2
% Pr�ctica: 1
%%%%%%
format short
c=2/3
format long
d= 20/3
format short e
e=2000/3
format long e
f=20000000000/3
format rat
g=1.333
%%%%%%