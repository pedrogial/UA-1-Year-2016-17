%%%%%%
% Nombre: Pedro Gim�nez Aldeguer
% DNI: 15419933C
% Fecha: 08/02/2017
% Grupo: 2
% Pr�ctica: 1
%%%%%%
x = [1 2 3 4 5]
r = [5.2 6.6 7.3 8.6 10.7]
plot(x, 'r*')
title('Cultivos')
xlabel('Tiempo (d�as)')
ylabel('Altura (cm)')
%%%%%%