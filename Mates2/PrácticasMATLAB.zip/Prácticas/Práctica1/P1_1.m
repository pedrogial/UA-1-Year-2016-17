%%%%%%
% Nombre: Pedro Gim�nez Aldeguer
% DNI: 15419933C
% Fecha: 08/02/2017
% Grupo: 2
% Pr�ctica: 1
%%%%%%
a=(5^2) + 7 -(26/2)
b= ((2^3)-7+11)/(3*(2^2))
%%%%%%