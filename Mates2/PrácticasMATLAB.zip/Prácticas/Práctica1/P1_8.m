%%%%%%
% Nombre: Pedro Gim�nez Aldeguer
% DNI: 15419933C
% Fecha: 08/02/2017
% Grupo: 2
% Pr�ctica: 1
%%%%%%
format short
l = 5
m = 7
n= sqrt(l^2 + m^2 - 2 * l * m * cos(pi/6))
%%%%%%
