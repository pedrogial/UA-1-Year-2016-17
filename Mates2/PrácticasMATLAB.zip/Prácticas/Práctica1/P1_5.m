%%%%%%
% Nombre: Pedro Gim�nez Aldeguer
% DNI: 15419933C
% Fecha: 08/02/2017
% Grupo: 2
% Pr�ctica: 1
%%%%%%
format long e
n=(1.4)*(10^154)
p=(1.3)*(10^154)
s=(n^2)-(p^2)
% 1. �Que ocurre con el resultado?
% S = Inf
% 2. �C�mo se puede solucionar el problema?
a=(n+p)*(n-p)
% Usando suma y resta de productos
