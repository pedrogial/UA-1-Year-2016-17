%%%%%%
% Nombre: Pedro Gim�nez Aldeguer
% DNI: 15419933C
% Fecha: 08/02/2017
% Grupo: 2
% Pr�ctica: 1
%%%%%%
syms x
ezplot('sin(x)',[(-3)*pi,pi])