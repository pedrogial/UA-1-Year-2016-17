%%%%%%
% Nombre: Pedro Gim�nez Aldeguer
% DNI: 15419933C
% Fecha: 08/02/2017
% Grupo: 2
% Pr�ctica: 1
%%%%%%
diary P1_4.m
P1_2
diary off
%%%%%%

c =

    0.6667


d =

   6.666666666666667


e =

   6.6667e+02


f =

     6.666666666666667e+09


g =

    1333/1000  

