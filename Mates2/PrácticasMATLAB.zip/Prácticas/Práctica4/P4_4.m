%%%%%%
% Nombre: Pedro Gim�nez Aldeguer
% DNI: 15419933C
% Fecha: 24/05/2017
% Grupo: 2
% Pr�ctica: 4
%%%%%%
Tamano = input('Tama�o: ')
Ingredientes = input('Ingredientes: ')
switch Tamano
    case 1,
        Precio = 5
        Ingredientes = Ingredientes * 3/2;
        Total = Precio + Ingredientes
        Total = Precio + Ingredientes
    case 2,
        Precio = 8
        Ingredientes = Ingredientes * 3/2;
        Total = Precio + Ingredientes
    case 3,
        Precio=12
        Ingredientes = Ingredientes * 3/2;
        Total = Precio + Ingredientes
    otherwise
        disp('ERROR -> tama�o incorrecto')
end