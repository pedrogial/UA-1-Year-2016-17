%%%%%%
% Nombre: Pedro Gim�nez Aldeguer
% DNI: 15419933C
% Fecha: 24/05/2017
% Grupo: 2
% Pr�ctica: 4
%%%%%%
r = input('Radio: ');
h = input('Altura: ');
Area = 2 * pi * r * (r+h)
Vol = pi * r^2 * h