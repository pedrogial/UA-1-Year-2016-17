%%%%%%
% Nombre: Pedro Gim�nez Aldeguer
% DNI: 15419933C
% Fecha: 24/05/2017
% Grupo: 2
% Pr�ctica: 4
%%%%%%

Tamano = input('Tama�o: ')
Ingredientes = input('Ingredientes: ')

if Tamanyo == 1
    
    Precio = 5;
    Ingredientes = Ingredientes * 3/2;
    Total = Precio + Ingredientes
else
    if Tamanyo == 2
        
        Precio = 8
        Ingredientes = Ingredientes * 3/2;
        Total = Precio + Ingredientes
    else
        if Tamanyo == 3
            
            Precio = 12;
            Ingredientes = Ingredientes * 3/2;
            Total = Precio + Ingredientes
        else
            disp('ERROR DE EJECUCION')
        end
    end
end
