%%%%%%
% Nombre: Pedro Gim�nez Aldeguer
% DNI: 15419933C
% Fecha: 24/05/2017
% Grupo: 2
% Pr�ctica: 4
%%%%%%
S = 0;
for i = 1: 1: 20
    for j = 1: 1: 20
        for k = 1: 1: 20
            if (i^2 + j^2) == k^2 && aux ~= i-1;
                fprintf('Valores: %i,%i,%i\n', i, j, k);
                S = i;
            end
        end
    end
end
