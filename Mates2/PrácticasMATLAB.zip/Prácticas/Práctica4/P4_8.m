%%%%%%
% Nombre: Pedro Gim�nez Aldeguer
% DNI: 15419933C
% Fecha: 24/05/2017
% Grupo: 2
% Pr�ctica: 4
%%%%%%
%Funcion
function x = raices(a, b, c);
x = (-b + sqrt(b^2 - (4 * a * c)))/(2 * a)
x = (-b - sqrt(b^2 - (4 * a * c)))/(2 * a)
%%%%%%Demostracion
a = input('a: ');
b = input('b: ');
c = input('c: ');

salida = raices(a,b,c);