%%%%%%
% Nombre: Pedro Gim�nez Aldeguer
% DNI: 15419933C
% Fecha: 24/05/2017
% Grupo: 2
% Pr�ctica: 4
%%%%%%
%Funcion
function x=celsius(c);
x=(c*9/5)+32;
%%%%%Demostracion
fh = input('Celsius: ');
salida = celsius(fh)
fprintf('%i Celsius son %-5.1f Fahrenheit \n',fh, salida)