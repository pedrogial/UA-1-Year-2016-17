%%%%%%
% Nombre: Pedro Gim�nez Aldeguer
% DNI: 15419933C
% Fecha: 24/05/2017
% Grupo: 2
% Pr�ctica: 4
%%%%%%
%Funcion
function x = knumeros(n)
i = 1;
sumatorio = 0;
while i <= n
    sumatorio = sumatorio + a^2;
    i = i + 1;
end
x = sumatorio;
%%%%%%Demostracion
k = input('Numero: ');
salida = knumeros(k);
fprintf('Suma:%i\n', salida)
